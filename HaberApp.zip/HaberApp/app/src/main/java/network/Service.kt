package network


import dto.Veri
import retrofit2.http.GET
import retrofit2.Call;
import retrofit2.http.Headers


interface Service {

        @GET(" articles")
        @Headers("apikey: 086f62c52ebc41378ea31e3cfe8a8584")
        fun getVeri():Call<List<Veri>>


}