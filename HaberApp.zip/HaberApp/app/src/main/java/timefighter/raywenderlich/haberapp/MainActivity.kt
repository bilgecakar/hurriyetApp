package timefighter.raywenderlich.haberapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import dto.Veri
import network.RetrofitClient
import network.Service
import retrofit2.Call
import retrofit2.Response
import javax.security.auth.callback.Callback

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val service = RetrofitClient.serviceBuilder().create(Service::class.java)

        service.getVeri().enqueue(object : retrofit2.Callback<List<Veri>> {
            override fun onFailure(call: Call<List<Veri>>, t: Throwable) {
                Log.d("sada","aasd")
            }

            override fun onResponse(call: Call<List<Veri>>, response: Response<List<Veri>>) {
                Log.d("sada","aasd")
            }

        })
    }
}
