package timefighter.raywenderlich.haberapp;

public class ContentType {
}
