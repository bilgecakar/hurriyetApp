package dto

data class MetaData(val Title : String,val Description: String)