package dto

data class File(val FileUrl : String,val Metadata: MetaData)